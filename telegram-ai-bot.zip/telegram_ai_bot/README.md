# Telegram AI Chat Bot

## যা লাগবে
- নতুন Telegram bot token
- Google AI Studio-এর Gemini API key
- GitHub account
- Render account

## Render-এ চালানোর ধাপ
1. এই project GitHub repository-তে upload করো।
2. Render → New → Background Worker → GitHub repo নির্বাচন করো।
3. Build command: `pip install -r requirements.txt`
4. Start command: `python bot.py`
5. Environment Variables-এ `TELEGRAM_BOT_TOKEN` এবং `GEMINI_API_KEY` যোগ করো।
6. Deploy করো।

Token বা API key কখনও public code বা chat-এ দিও না।
