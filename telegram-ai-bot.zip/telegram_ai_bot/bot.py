import os
import logging
from telegram import Update
from telegram.constants import ChatAction
from telegram.ext import Application, CommandHandler, MessageHandler, ContextTypes, filters
from google import genai
from google.genai import types

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

TELEGRAM_BOT_TOKEN = os.environ.get("TELEGRAM_BOT_TOKEN")
GEMINI_API_KEY = os.environ.get("GEMINI_API_KEY")
MODEL = os.environ.get("GEMINI_MODEL", "gemini-2.5-flash")

if not TELEGRAM_BOT_TOKEN:
    raise RuntimeError("TELEGRAM_BOT_TOKEN is missing")
if not GEMINI_API_KEY:
    raise RuntimeError("GEMINI_API_KEY is missing")

client = genai.Client(api_key=GEMINI_API_KEY)
search_tool = types.Tool(google_search=types.GoogleSearch())

SYSTEM_PROMPT = """তুমি একটি সহায়ক বাংলা Telegram AI assistant। ব্যবহারকারীর ভাষায় উত্তর দাও।
প্রয়োজনে Google Search grounding ব্যবহার করে সাম্প্রতিক তথ্য যাচাই করো।
উত্তর সংক্ষিপ্ত, পরিষ্কার ও বাস্তবধর্মী রাখো। নিশ্চিত না হলে সেটা স্পষ্ট বলো, বানিয়ে তথ্য দিও না।
"""

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text(
        "আসসালামু আলাইকুম! আমি AI chat bot। যেকোনো প্রশ্ন লিখে পাঠান।\n\n"
        "/help লিখলে ব্যবহারবিধি দেখাব।"
    )

async def help_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text(
        "প্রশ্ন লিখে পাঠান, আমি উত্তর দেব। সাম্প্রতিক তথ্যের দরকার হলে Google Search ব্যবহার করব।"
    )

async def answer(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not update.message or not update.message.text:
        return
    question = update.message.text.strip()
    if not question:
        return

    await update.message.chat.send_action(ChatAction.TYPING)
    try:
        response = client.models.generate_content(
            model=MODEL,
            contents=f"{SYSTEM_PROMPT}\n\nব্যবহারকারীর প্রশ্ন:\n{question}",
            config=types.GenerateContentConfig(
                temperature=0.4,
                tools=[search_tool],
            ),
        )
        text = (response.text or "দুঃখিত, এই প্রশ্নের উত্তর তৈরি করতে পারিনি।").strip()
        # Telegram message limit is 4096 chars.
        for i in range(0, len(text), 4000):
            await update.message.reply_text(text[i:i + 4000])
    except Exception:
        logger.exception("AI request failed")
        await update.message.reply_text(
            "এখন উত্তর দিতে সমস্যা হচ্ছে। কিছুক্ষণ পর আবার চেষ্টা করুন।"
        )

async def error_handler(update: object, context: ContextTypes.DEFAULT_TYPE):
    logger.exception("Unhandled bot error", exc_info=context.error)


def main():
    app = Application.builder().token(TELEGRAM_BOT_TOKEN).build()
    app.add_handler(CommandHandler("start", start))
    app.add_handler(CommandHandler("help", help_command))
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, answer))
    app.add_error_handler(error_handler)
    app.run_polling(allowed_updates=Update.ALL_TYPES)

if __name__ == "__main__":
    main()
